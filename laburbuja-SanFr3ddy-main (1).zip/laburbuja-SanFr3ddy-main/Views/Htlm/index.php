<?php
// Redireccionar a otra página
header("Location: login.php");
// Asegurarse de que el script se detenga después de la redirección
exit();
?>